import { Music, Palette, Trophy, Users } from "lucide-react";
import { Card } from "@/app/components/ui/card";

export function About() {
  const features = [
    {
      icon: Music,
      title: "Musical Nights",
      description: "Live performances by renowned artists and bands",
    },
    {
      icon: Palette,
      title: "Cultural Events",
      description: "Dance, drama, and art exhibitions",
    },
    {
      icon: Trophy,
      title: "Competitions",
      description: "Compete in various events and win exciting prizes",
    },
    {
      icon: Users,
      title: "Networking",
      description: "Connect with students from colleges across the country",
    },
  ];

  return (
    <section id="about" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl mb-4 text-gray-900">
            About Prashast
          </h2>
          <p className="text-lg sm:text-xl text-gray-600 max-w-3xl mx-auto">
            Prashast is the most anticipated annual tech, sports & cultural festival celebrating talent, creativity, and innovation. 
            Join thousands of students for eight unforgettable days of entertainment, competition, and celebration.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {features.map((feature) => (
            <Card
              key={feature.title}
              className="p-6 text-center hover:shadow-xl transition-shadow border-2 hover:border-purple-300"
            >
              <div className="flex justify-center mb-4">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
                  <feature.icon className="text-white" size={32} />
                </div>
              </div>
              <h3 className="text-xl mb-2 text-gray-900">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </Card>
          ))}
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          <div>
            <div className="text-4xl sm:text-5xl mb-2 bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
              50+
            </div>
            <div className="text-gray-600">Events</div>
          </div>
          <div>
            <div className="text-4xl sm:text-5xl mb-2 bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
              5000+
            </div>
            <div className="text-gray-600">Participants</div>
          </div>
          <div>
            <div className="text-4xl sm:text-5xl mb-2 bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
              100+
            </div>
            <div className="text-gray-600">Colleges</div>
          </div>
          <div>
            <div className="text-4xl sm:text-5xl mb-2 bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
              ₹5L+
            </div>
            <div className="text-gray-600">Prize Money</div>
          </div>
        </div>
      </div>
    </section>
  );
}