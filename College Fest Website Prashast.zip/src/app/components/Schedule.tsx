import { Calendar, Clock } from "lucide-react";
import { Card } from "@/app/components/ui/card";

export function Schedule() {
  const schedule = [
    {
      day: "Day 1-2",
      date: "February 15-16, 2026",
      events: [
        { time: "10:00 AM", title: "Opening Ceremony", venue: "Main Auditorium" },
        { time: "11:00 AM", title: "Blind Coding", venue: "Tech Lab" },
        { time: "02:00 PM", title: "Volleyball Tournament", venue: "Sports Ground" },
        { time: "03:00 PM", title: "Cricket Match", venue: "Cricket Field" },
        { time: "05:00 PM", title: "E-Sports & Robotics", venue: "Tech Arena" },
      ],
    },
    {
      day: "Day 3-4",
      date: "February 17-18, 2026",
      events: [
        { time: "09:00 AM", title: "Hackathons & Codeathons", venue: "Tech Lab" },
        { time: "11:00 AM", title: "Badminton Tournament", venue: "Indoor Stadium" },
        { time: "01:00 PM", title: "100 Meter Race", venue: "Sports Ground" },
        { time: "03:00 PM", title: "Spell Bee & Debate", venue: "Auditorium" },
        { time: "05:00 PM", title: "Chess & Carrom", venue: "Recreation Hall" },
      ],
    },
    {
      day: "Day 5-6",
      date: "February 19-20, 2026",
      events: [
        { time: "10:00 AM", title: "3D Modeling & Printing", venue: "Design Lab" },
        { time: "11:00 AM", title: "Kabaddi Match", venue: "Sports Ground" },
        { time: "02:00 PM", title: "Tug of War", venue: "Open Arena" },
        { time: "03:00 PM", title: "Arm Wrestling", venue: "Sports Complex" },
        { time: "05:00 PM", title: "Line Follower & Circuit Challenges", venue: "Tech Lab" },
      ],
    },
    {
      day: "Day 7-8",
      date: "February 21-22, 2026",
      events: [
        { time: "11:00 AM", title: "3-Legged Race", venue: "Sports Ground" },
        { time: "02:00 PM", title: "Final Matches & Competitions", venue: "Various Venues" },
        { time: "05:00 PM", title: "Closing Ceremony", venue: "Main Auditorium" },
        { time: "07:00 PM", title: "Cultural Night - Dance & Music", venue: "Main Stage" },
        { time: "09:00 PM", title: "Prize Distribution", venue: "Main Auditorium" },
      ],
    },
  ];

  return (
    <section id="schedule" className="py-20 bg-gradient-to-b from-purple-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl mb-4 text-gray-900">
            Event Schedule
          </h2>
          <p className="text-lg sm:text-xl text-gray-600 max-w-3xl mx-auto">
            Eight action-packed days filled with amazing events and performances
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {schedule.map((day) => (
            <Card
              key={day.day}
              className="p-6 border-2 hover:border-purple-300 transition-colors"
            >
              <div className="mb-6">
                <div className="flex items-center gap-2 mb-2">
                  <Calendar className="text-purple-600" size={24} />
                  <h3 className="text-2xl text-gray-900">{day.day}</h3>
                </div>
                <p className="text-gray-600">{day.date}</p>
              </div>

              <div className="space-y-4">
                {day.events.map((event, index) => (
                  <div
                    key={index}
                    className="border-l-4 border-purple-400 pl-4 py-2 hover:bg-purple-50 transition-colors rounded-r"
                  >
                    <div className="flex items-center gap-2 mb-1">
                      <Clock className="text-purple-600" size={16} />
                      <span className="text-sm text-purple-600">{event.time}</span>
                    </div>
                    <h4 className="text-gray-900 mb-1">{event.title}</h4>
                    <p className="text-sm text-gray-500">{event.venue}</p>
                  </div>
                ))}
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}