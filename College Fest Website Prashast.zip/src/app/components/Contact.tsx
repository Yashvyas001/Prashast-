import { Mail, MapPin, Phone } from "lucide-react";
import { useState } from "react";
import { Button } from "@/app/components/ui/button";
import { Input } from "@/app/components/ui/input";
import { Card } from "@/app/components/ui/card";

export function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    college: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert(
      "Thank you for registering! We will contact you soon.",
    );
    setFormData({
      name: "",
      email: "",
      phone: "",
      college: "",
    });
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement>,
  ) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  return (
    <section
      id="contact"
      className="py-20 bg-gradient-to-b from-white to-purple-50"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl mb-4 text-gray-900">
            Register Now
          </h2>
          <p className="text-lg sm:text-xl text-gray-600 max-w-3xl mx-auto">
            Don't miss out on the biggest tech, sports &
            cultural fest of the year. Register now and be part
            of Prashast 2026!
          </p>
          <div className="mt-6 inline-block bg-gradient-to-r from-purple-600 to-pink-600 text-white px-8 py-4 rounded-lg text-2xl">
            Entry Fees: ₹300
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <Card className="p-8">
            <h3 className="text-2xl mb-6 text-gray-900">
              Registration Form
            </h3>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm mb-2 text-gray-700">
                  Full Name *
                </label>
                <Input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  placeholder="Enter your name"
                  required
                />
              </div>
              <div>
                <label className="block text-sm mb-2 text-gray-700">
                  Email *
                </label>
                <Input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="Enter your email"
                  required
                />
              </div>
              <div>
                <label className="block text-sm mb-2 text-gray-700">
                  Phone Number *
                </label>
                <Input
                  type="tel"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  placeholder="Enter your phone number"
                  required
                />
              </div>
              <div>
                <label className="block text-sm mb-2 text-gray-700">
                  College Name *
                </label>
                <Input
                  type="text"
                  name="college"
                  value={formData.college}
                  onChange={handleChange}
                  placeholder="Enter your college name"
                  required
                />
              </div>
              <Button
                type="submit"
                className="w-full"
                size="lg"
              >
                Submit Registration
              </Button>
            </form>
          </Card>

          <div className="space-y-6">
            <Card className="p-6">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center flex-shrink-0">
                  <MapPin className="text-white" size={24} />
                </div>
                <div>
                  <h4 className="text-lg mb-2 text-gray-900">
                    Location
                  </h4>
                  <p className="text-gray-600">
                    Regional College Campus
                    <br />
                    Sitapura, Jaipur
                    <br />A unit of Deepshikha Group of Colleges
                  </p>
                </div>
              </div>
            </Card>

            <Card className="p-6">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center flex-shrink-0">
                  <Phone className="text-white" size={24} />
                </div>
                <div>
                  <h4 className="text-lg mb-2 text-gray-900">
                    Phone
                  </h4>
                  <p className="text-gray-600">
                    Harsh Sharma: 9079934306
                    <br />
                    Yash Vyas: 8005748561
                  </p>
                </div>
              </div>
            </Card>

            <Card className="p-6">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center flex-shrink-0">
                  <Mail className="text-white" size={24} />
                </div>
                <div>
                  <h4 className="text-lg mb-2 text-gray-900">
                    Email
                  </h4>
                  <p className="text-gray-600">
                    info@regionalcollegejaipur.com
                    <br />
                    prashast@regionalcollegejaipur.com
                  </p>
                </div>
              </div>
            </Card>

            <Card className="p-6 bg-gradient-to-r from-purple-600 to-pink-600 text-white">
              <h4 className="text-xl mb-2">
                Early Bird Offer!
              </h4>
              <p className="mb-4">
                Register before February 10, 2026 and get 20%
                off on entry passes!
              </p>
              <p className="text-sm opacity-90">
                Limited slots available. Hurry up!
              </p>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}