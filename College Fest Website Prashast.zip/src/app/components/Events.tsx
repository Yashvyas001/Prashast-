import { Music, Palette, Mic, Camera, Code, Lightbulb } from "lucide-react";
import { Card } from "@/app/components/ui/card";
import { ImageWithFallback } from "@/app/components/figma/ImageWithFallback";

export function Events() {
  const events = [
    {
      icon: Music,
      title: "Battle of Bands",
      category: "Music",
      image: "https://images.unsplash.com/photo-1689793354800-de168c0a4c9b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtdXNpYyUyMGNvbmNlcnQlMjBzdGFnZSUyMGxpZ2h0c3xlbnwxfHx8fDE3Njk3NjExOTR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      description: "Show your musical talent and rock the stage",
    },
    {
      icon: Palette,
      title: "Dance Championship",
      category: "Dance",
      image: "https://images.unsplash.com/photo-1698824554771-293b5dcc42db?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkYW5jZSUyMHBlcmZvcm1hbmNlJTIwc3RhZ2V8ZW58MXx8fHwxNzY5NzYxMTk1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      description: "Express yourself through various dance forms",
    },
    {
      icon: Mic,
      title: "Stand-Up Comedy",
      category: "Entertainment",
      image: "https://images.unsplash.com/photo-1769432902785-b17b57e67de0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjdWx0dXJhbCUyMGV2ZW50JTIwcGVyZm9ybWFuY2V8ZW58MXx8fHwxNzY5NjcwMDg5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      description: "Make everyone laugh with your comedy skills",
    },
    {
      icon: Camera,
      title: "Photography Contest",
      category: "Visual Arts",
      image: "https://images.unsplash.com/photo-1693608231470-25e1b16a23b9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2xsZWdlJTIwY2FtcHVzJTIwc3R1ZGVudHN8ZW58MXx8fHwxNzY5NzYxMTk1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      description: "Capture moments and showcase your photography",
    },
    {
      icon: Code,
      title: "Hackathon",
      category: "Technology",
      image: "https://images.unsplash.com/photo-1768590149034-c372f0c3a07c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZWNoJTIwaW5ub3ZhdGlvbiUyMGV4aGliaXRpb258ZW58MXx8fHwxNzY5NzYxMTk2fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      description: "24-hour coding competition for tech enthusiasts",
    },
    {
      icon: Lightbulb,
      title: "Drama Competition",
      category: "Theatre",
      image: "https://images.unsplash.com/photo-1769432902785-b17b57e67de0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjdWx0dXJhbCUyMGV2ZW50JTIwcGVyZm9ybWFuY2V8ZW58MXx8fHwxNzY5NjcwMDg5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      description: "Showcase your acting prowess on stage",
    },
  ];

  return (
    <section id="events" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl mb-4 text-gray-900">
            Featured Events
          </h2>
          <p className="text-lg sm:text-xl text-gray-600 max-w-3xl mx-auto">
            Participate in exciting competitions and showcase your talent across multiple categories
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {events.map((event) => (
            <Card
              key={event.title}
              className="overflow-hidden hover:shadow-2xl transition-shadow group"
            >
              <div className="relative h-48 overflow-hidden">
                <ImageWithFallback
                  src={event.image}
                  alt={event.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute top-4 right-4 bg-white px-3 py-1 rounded-full text-sm text-purple-600">
                  {event.category}
                </div>
              </div>
              <div className="p-6">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
                    <event.icon className="text-white" size={20} />
                  </div>
                  <h3 className="text-xl text-gray-900">{event.title}</h3>
                </div>
                <p className="text-gray-600 mb-4">{event.description}</p>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}