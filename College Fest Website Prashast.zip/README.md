
  # College Fest Website Prashast

  This is a code bundle for College Fest Website Prashast. The original project is available at https://www.figma.com/design/Z9zlgFLnPLmFp7RJ2nd1OZ/College-Fest-Website-Prashast.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  